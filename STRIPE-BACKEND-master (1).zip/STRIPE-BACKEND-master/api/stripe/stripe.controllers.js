//set stripe secret key
const stripe = require("stripe")("sk_live_UhcVsqPpT7Sd7eAzVll52mV5004SftQbLR");

module.exports = class StripeController {
  charge(req, res, next) {
    //get token and amount from request
    const { token, amount, description, firstName, lastName, email, phone } = req.body;

    //charge from stripe
    stripe.charges.create(
      {
        amount: amount,
        currency: "EUR",
        description: description,
        source: token
      },
      function(err, charge) {
        if (err) {
          switch (err.type) {
            case "StripeCardError":
              // A declined card error
              err.message; // => e.g. "Your card's expiration year is invalid."
              break;
            case "StripeRateLimitError":
              // Too many requests made to the API too quickly
              break;
            case "StripeInvalidRequestError":
              // Invalid parameters were supplied to Stripe's API
              break;
            case "StripeAPIError":
              // An error occurred internally with Stripe's API
              break;
            case "StripeConnectionError":
              // Some kind of error occurred during the HTTPS communication
              break;
            case "StripeAuthenticationError":
              // You probably used an incorrect API key
              break;
            default:
              // Handle any other types of unexpected errors
              break;
          }
          console.log(JSON.stringify(err, null, 2));
          res.send({ status: 0, msg: err.message });
        }
         //create customer
         stripe.customers.create({
          email:email,
          name:firstName+' '+lastName,
          phone:phone
        });
        res.send({ status: 1, response: charge });
      }
    );
  }
};
