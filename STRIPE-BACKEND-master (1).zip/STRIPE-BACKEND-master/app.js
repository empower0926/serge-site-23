require('./setup/env');
const Server = require('./setup/server');

const routes = require('./routes');

const port = parseInt(process.env.PORT) || 3000;
module.exports = new Server().router(routes).listen(port);
