const stripeRoutes = require('./api/stripe/stripe.routes');

module.exports = function routes(app) {
  app.use('/', [stripeRoutes]);
};
